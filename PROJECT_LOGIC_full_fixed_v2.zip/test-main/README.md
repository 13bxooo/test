# PROJECT : LOGIC

Streamlit project. Keep the `pages/` folder and `assets/lab_background.jpeg` alongside `main.py`. Keep `neodgm.ttf` to preserve the NeoDungGeunMo font. Do not upload `__pycache__` or `.pyc` files.

Updated behaviors: NEW GAME resets prior run saves; RESTART begins at Stage 01; TITLE routes back to the title screen; Stage 02 opens with an opaque black ECHO dialogue, then displays the Stage 02 card/loading transition before the lab gameplay.
